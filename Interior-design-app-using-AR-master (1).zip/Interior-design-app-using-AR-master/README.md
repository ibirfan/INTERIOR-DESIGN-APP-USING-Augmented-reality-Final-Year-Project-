# Interior-design-app-using-AR
It is an application which the furniture and furnishings will develop in three dimensional surface of object and present by using augmented reality. It is the application that can be use in the mobile phones, tab and etc. especially using Android platform to choose furniture that suitable for their house.

Check my blog also to get all information about project 
https://medium.com/@gansawant07/interior-design-app-using-ar-6957cecdf1da
